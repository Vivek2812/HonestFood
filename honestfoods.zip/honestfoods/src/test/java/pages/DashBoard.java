package pages;

import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.FluentWait;
import org.testng.Assert;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;


public class DashBoard {
	WebDriver oDriver;
	ExtentReports oExtentReports;
	ExtentTest oExtentTest;
	HashMap dictionary;

	public DashBoard(WebDriver oDriver, ExtentReports oExtentReports, ExtentTest oExtentTest, HashMap dictionary)
	{

		this.oExtentReports=oExtentReports;
		this.oDriver=oDriver;
		this.dictionary=dictionary;
		this.oExtentTest=oExtentTest;
	}	

	By search = By.xpath("//div[@id=\"social-content-hub\"]/div/div[1]/div/div/div[3]");
	By Cricket =By.xpath("//div[@id=\"social-content-hub\"]/div/div[1]/div/div/div[3]//input");
	By clearText=By.xpath("//input[@type='text']/../span");
	By Football=By.xpath("//input[@type='text']");

	By searchTag=By.xpath("//li//a//em");

	//this method validates widget search
	public boolean SearchButton( String serchItem) {

		final By text = By.xpath("//input[@value='"+serchItem+"']");

		WebElement eBtnPass = oDriver.findElement(search);
		WebElement eCricket = oDriver.findElement(Cricket);


		Actions action = new Actions(oDriver);
		action.moveToElement(eBtnPass).click().perform();

		eCricket.sendKeys(serchItem);
		eCricket.sendKeys(Keys.ENTER);

		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(oDriver)
				.withTimeout(30, TimeUnit.SECONDS)
				.pollingEvery(5, TimeUnit.SECONDS)
				.ignoring(NoSuchElementException.class);

		WebElement element = wait.until(new Function<WebDriver, WebElement>() {
			public WebElement apply(WebDriver oDriver) {
				WebElement element1 = oDriver.findElement(text);

				return element1;
			}
		});

		Assert.assertTrue(element.isDisplayed());
		Assert.assertTrue(element.isEnabled());

		oExtentTest.log(LogStatus.PASS,"Serching Item");
		return true;
	}

	//This method vaidated inner page search validatiojn
	public boolean newSearchButton( String serchItem) {

		WebElement element = oDriver.findElement(clearText);

		element.click();
		oDriver.findElement(Football).sendKeys(serchItem);

		oExtentTest.log(LogStatus.PASS,"Item Searched");

		return true;

	}

	//this method validates search autocomplete feature
	public boolean validateSearchCards(String textToSearch) throws InterruptedException {

		this.SearchButton("Something");
		this.newSearchButton(textToSearch);

		Thread.sleep(20000);
		List<WebElement> searchTags=oDriver.findElements(searchTag);

		System.out.println(searchTags.size());
		int  flag=-1;
		if (searchTags.size()>0) flag=0;

		for(WebElement  searchText : searchTags) {

			System.out.println(searchText.getText().trim());

			if((searchText.getText().toLowerCase().contains(textToSearch))==true) flag=0;
			else {flag=1;break;}
		}

		if (flag==1) {
			oExtentTest.log(LogStatus.FAIL,"Item Searched");

			return false;
		}
		else {

			oExtentTest.log(LogStatus.PASS,"Item Searched");
			return true;
		}

	}

}
