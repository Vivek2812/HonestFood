package tests;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.project.honestfoods.AutomationConstants;
import com.project.honestfoods.MyTestNGBaseClass;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import pages.DashBoard;


public class TestCaseOne extends MyTestNGBaseClass {
	static HashMap dataMap = null;

	@Test
	public void validation() throws Throwable{
		
		oDriver.get("https://www.unibet.co.uk/blog");
		
		oExtentTest=oExtentReport.startTest("Go Search");
		DashBoard obj = new DashBoard(oDriver,oExtentReport,oExtentTest,dataMap);
		AssertJUnit.assertTrue(obj.SearchButton("Cricket"));
		AssertJUnit.assertTrue(obj.newSearchButton("FootBall"));
		AssertJUnit.assertTrue(obj.validateSearchCards("cric".toLowerCase()));

	}

}



